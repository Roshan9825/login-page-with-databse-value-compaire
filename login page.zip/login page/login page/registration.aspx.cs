﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace login_page
{
    public partial class registration : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source= CH0002\\SQLSERVER2012; Integrated Security=SSPI;  Initial Catalog= EMP;");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand(@"INSERT INTO [dbo].[idpass]
           ([username]
           ,[pass])
     VALUES
           ('"+TextBox1.Text+"','"+TextBox2.Text+"')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            Response.Redirect("WebForm1.aspx");
            con.Close();
        }
    }
}