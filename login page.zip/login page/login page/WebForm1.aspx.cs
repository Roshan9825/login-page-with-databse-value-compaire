﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace login_page
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("Data Source= CH0002\\SQLSERVER2012; Integrated Security=true;  Initial Catalog= EMP;");

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sqladapter = new SqlDataAdapter("select * from idpass where username='"+TextBox1.Text+"'and pass='" + TextBox2.Text+"' ",con);
            DataTable dt = new DataTable();
            sqladapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Response.Redirect("http://chicinfotech.com/");
            }
            else
            {
                Label1.Text = "incorrect id or password plz enter corect id password " ;
                Label1.ForeColor = System.Drawing.Color.Red;

            }
        }

       

        protected void LinkButton1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("registration.aspx");
        }
    }
}