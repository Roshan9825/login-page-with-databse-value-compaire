use emp;

create table idpass(
id int primary key not null identity,
username varchar(50),
pass varchar(16)
);


select * from idpass;